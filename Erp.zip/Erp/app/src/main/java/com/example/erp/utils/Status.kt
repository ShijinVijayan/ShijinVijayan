package com.example.erp.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}