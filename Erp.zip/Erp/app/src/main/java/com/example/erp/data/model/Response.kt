package com.example.erp.data.model

data class Response(
    val docs: List<Doc>,
    val meta: Meta
)