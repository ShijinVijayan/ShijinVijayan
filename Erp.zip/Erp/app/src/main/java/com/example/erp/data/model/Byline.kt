package com.example.erp.data.model

data class Byline(
    val organization: Any,
    val original: String,
    val person: List<Person>
)