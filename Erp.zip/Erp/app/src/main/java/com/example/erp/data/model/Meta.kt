package com.example.erp.data.model

data class Meta(
    val hits: Int,
    val offset: Int,
    val time: Int
)