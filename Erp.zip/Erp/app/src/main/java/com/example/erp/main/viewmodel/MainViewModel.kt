package com.example.erp.main.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.example.erp.data.model.Articles
import com.example.erp.data.repository.ArticleRepository
import com.example.erp.utils.Resource
import kotlinx.coroutines.Dispatchers
import java.lang.Exception

class MainViewModel (private val articleRepository: ArticleRepository) : ViewModel(){

    fun getArticles() = liveData<Resource<List<Articles>>>(Dispatchers.IO){

        emit(Resource.loading(data = null))
        try {
        emit(Resource.success(data = articleRepository.getArticles()))
    }catch (exception:Exception){
        emit(Resource.error(data = null,message = exception.message?: "Error Occurred"))

    }
    }
}