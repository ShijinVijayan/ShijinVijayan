package com.example.erp.main.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.erp.R
import com.example.erp.data.model.Articles
import com.example.erp.data.model.Multimedia
import kotlinx.android.synthetic.main.item_layout.view.*

class MainAdapter(private val multimedia: ArrayList<Multimedia>):RecyclerView.Adapter<MainAdapter.DataViewHolder>() {
    class DataViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        fun bind(multimedias: Multimedia){
            itemView.apply {
                textViewUserName.text = multimedias.rank.toString()
                textViewUserEmail.text = multimedias.subtype
                Glide.with(imageViewAvatar.context)
                    .load(multimedias.url)
                    .into(imageViewAvatar)

            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder =
        DataViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_layout,parent,false))


    override fun getItemCount(): Int {
        return multimedia.size

    }

    override fun onBindViewHolder(holder: DataViewHolder, position: Int) {
        holder.bind(multimedia[position])
    }


    fun addUsers(multi:List<Articles>){
        this.multimedia.apply {
            clear()
            addAll(multimedia)
        }

    }
}