package com.example.erp.data.model

data class Articles(
    val copyright: String,
    val response: Response,
    val status: String
)