package com.example.erp.data.responses

data class LoginResponse(
    val email: String,
    val first_name: String,
    val gender: String,
    val id: String,
    val image: String,
    val last_name: String,
    val password: String,
    val phone: String,
    val role: String,
    val status: String,
    val user: String
)