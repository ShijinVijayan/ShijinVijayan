package com.example.erp.data

import android.content.Context
import androidx.datastore.core.DataStore
import java.util.prefs.Preferences


class UserPreferences(
    context: Context
){

    private val applicationContext = context.applicationContext
   // private val dataStore: DataStore<Preferences>

    /*init {
        dataStore = applicationContext.createDataStore(
            name = "my_data_store"
        )
    }*/
}