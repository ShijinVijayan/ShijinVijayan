package com.example.erp.data.network

import com.example.erp.data.model.Articles
import retrofit2.http.GET

interface ApiService {

    @GET("articlesearch.json?q=election&api-key=fy0Kdr6SJymAAj2Z7ZeVSLVq9Gapiltl")
    suspend fun getArticles(): List<Articles>
}