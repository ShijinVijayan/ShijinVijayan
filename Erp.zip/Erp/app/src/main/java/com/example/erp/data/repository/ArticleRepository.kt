package com.example.erp.data.repository

import com.example.erp.data.network.ApiHelper

class ArticleRepository(private val apiHelper: ApiHelper) {
    suspend fun getArticles() = apiHelper.getArticles()
}