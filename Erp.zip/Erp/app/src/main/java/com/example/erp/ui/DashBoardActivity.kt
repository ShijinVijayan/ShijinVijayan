package com.example.erp.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.erp.R
import com.example.erp.data.model.Articles
import com.example.erp.data.network.ApiHelper
import com.example.erp.data.network.RetrofitBuilder
import com.example.erp.main.adapter.MainAdapter
import com.example.erp.main.viewmodel.MainViewModel
import com.example.erp.userinterface.base.ViewModelFactory1
import com.example.erp.utils.Status
import kotlinx.android.synthetic.main.activity_dash_board.*

class DashBoardActivity : AppCompatActivity() {
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: MainAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dash_board)

        val recy=findViewById<RecyclerView>(R.id.recyclerView)
        setupViewModel()
        setupUI(recy)
        setupObservers()
    }

    private fun setupObservers() {

        viewModel.getArticles().observe(this, Observer {
            it?.let { resource ->
                Log.e("STATUSZZZZZ",""+resource.status)
                when (resource.status){

                    Status.SUCCESS ->{
                        recyclerView.visibility = View.VISIBLE
                        progressBar.visibility = View.GONE


                        resource.data?.let { multi -> retrieveList(multi)  }
                    }
                    Status.ERROR ->{
                        recyclerView.visibility = View.VISIBLE
                        progressBar.visibility = View.GONE
                        Toast.makeText(this,it.message, Toast.LENGTH_LONG).show()
                    }
                    Status.LOADING ->{
                        progressBar.visibility = View.VISIBLE
                        recyclerView.visibility = View.GONE
                    }
                }
            }
        })
    }

    private fun setupUI(recyclerView: RecyclerView) {
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = MainAdapter(arrayListOf())
        recyclerView.addItemDecoration(
            DividerItemDecoration(
                recyclerView.context,
                (recyclerView.layoutManager as LinearLayoutManager).orientation
            )
        )
        recyclerView.adapter = adapter
    }



    //To set ViewModel
    private fun setupViewModel() {
        viewModel = ViewModelProviders.of(this,
            ViewModelFactory1(ApiHelper(RetrofitBuilder.apiService))
        ).get(MainViewModel::class.java)
    }



    private fun retrieveList(multi: List<Articles>){
        adapter.apply {
            addUsers(multi)
            notifyDataSetChanged()
        }
    }
}