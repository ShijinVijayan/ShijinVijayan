package com.example.erp.data.network

class ApiHelper(private val apiService: ApiService) {
    suspend fun getArticles() = apiService.getArticles()
}