package com.example.erp.userinterface.base

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.erp.data.network.ApiHelper
import com.example.erp.data.repository.ArticleRepository
import com.example.erp.main.viewmodel.MainViewModel

class ViewModelFactory1(private val apiHelper: ApiHelper): ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)){
            return MainViewModel(ArticleRepository(apiHelper))as T
        }
        throw IllegalArgumentException("Unknown class Name")
    }



}